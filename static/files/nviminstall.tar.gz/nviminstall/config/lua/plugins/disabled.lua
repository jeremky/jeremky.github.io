return {
  { "windwp/nvim-ts-autotag",   enabled = false },
  { "Saghen/blink.cmp",         enabled = false },
  { "akinsho/bufferline.nvim",  enabled = false },
  { "stevearc/conform.nvim",    enabled = false },
  { "folke/flash.nvim",         enabled = false },
  { "MagicDuck/grug-far.nvim",  enabled = false },
  { "echasnovski/mini.ai",      enabled = false },
  { "folke/todo-comments.nvim", enabled = false },
  { "folke/tokyonight.nvim",    enabled = false },
  { "folke/trouble.nvim",       enabled = false },
  { "folke/ts-comments.nvim",   enabled = false },
}
