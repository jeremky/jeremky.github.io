##################################################################
## Bash

# Affichage
PS1='\[\033[01;36m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w \$\[\033[00m\] '

# Variables
export LANG=fr_FR.UTF-8
export LANGUAGE=$LANG
export LC_ALL=$LANG
export EDITOR=vi
export VISUAL=$EDITOR

# Tweaks divers
if [[ $- == *i* ]]; then
  bind 'set colored-stats on'              # Affiche les couleurs lors de la complétion
  bind 'set completion-ignore-case on'     # Ignorer la casse lors de la complétion
  bind 'set show-all-if-unmodified on'     # Affiche les correspondances possibles immédiatement
  bind 'set show-all-if-ambiguous on'      # Saisie automatique à partir des correspondances
fi

##################################################################
## Commandes

# Prompt
alias ls='ls --color=auto'                         # Ajoute la couleur
alias l='ls -lh'                                   # Liste détaillée
alias la='ls -lhA'                                 # Liste avec les fichiers cachés
alias lr='ls -lLhR'                                # Liste en récursif
alias lra='ls -lhRA'                               # Liste en récursif avec les fichiers cachés
alias lrt='ls -lLhrt'                              # Liste par date
alias lrta='ls -lLhrtA'                            # Liste par date avec les fichiers cachés
alias grep='grep -i --color=auto'                  # Grep sans la sensibilité à la casse
alias zgrep='zgrep -i --color=auto'                # Grep dans les fichiers compressés
alias psp='ps -eaf | grep -v grep | grep'          # Chercher un process (psp <nom process>)
alias iostat='iostat -m --human'                   # Commande iostat lisible
alias ifconfig='ip addr'                           # Afficher les adresses IP (ifconfig n'existe plus)
alias md5='md5sum <<<'                             # Facilite l'utilisation de la commande md5
alias pubip='curl -s -4 ipecho.net/plain ; echo'   # Pour obtenir l'adresse IP publique du serveur
alias df='df -h -x tmpfs -x devtmpfs -x overlay'   # Commande df en filtrant les montages inutiles

# ssh
alias genkey='ssh-keygen -t ed25519 -a 100'        # Générer une clé ed25519
alias genkeyrsa='ssh-keygen -t rsa -b 4096 -a 100' # Générer une clé RSA
alias copykey='ssh-copy-id'                        # Copier la clé ssh vers un serveur

# apk : gestionnaire de paquets
if [[ -f /sbin/apk ]]; then
  alias apk='sudo apk'
  alias upgrade='sudo apk update && sudo apk upgrade'
fi

##################################################################
## Applications facultatives

# colordiff : diff avec couleur
[[ -f /usr/bin/colordiff ]] && alias diff='colordiff'

# fzf : recherche avancée
if [[ -f /usr/bin/fzf ]]; then
  eval "$(fzf --bash)"
  export FZF_DEFAULT_OPTS=" \
    --color=bg+:#363a4f,bg:#24273a,spinner:#f4dbd6,hl:#ed8796 \
    --color=fg:#cad3f5,header:#ed8796,info:#c6a0f6,pointer:#f4dbd6 \
    --color=marker:#b7bdf8,fg+:#cad3f5,prompt:#c6a0f6,hl+:#ed8796 \
    --color=border:#363a4f,label:#cad3f5"
fi

# htop : plus convivial que top
[[ -f /usr/bin/htop ]] && alias top='htop'

# ncdu : équivalent à TreeSize
[[ -f /usr/bin/ncdu ]] && alias ncdu='ncdu --color dark'

# rg : plus performant que grep
[[ -f /usr/bin/rg ]] && alias rg='rg -i --no-ignore'

# tmux : émulateur de terminal
[[ -f /usr/bin/tmux ]] && alias tmux='tmux attach || tmux new'

# vim : vi amélioré
[[ -f /usr/bin/vim ]] && alias vi='vim -nO'

# zoxide : cd amélioré
[[ -f /usr/bin/zoxide ]] && eval "$(zoxide init bash)"

##################################################################
## Fonctions

# cpsave : copie un fichier ou un dossier avec .old
cpsave() { cp -Rp $1 "$(echo $1 | cut -d '/' -f 1)".old ;}

# tarc
tarc() { for file in $* ; do tar czvf "$(echo $file | cut -d '/' -f 1)".tar.gz $file ; done ;}

# tarx
tarx() { for file in $* ; do tar xzvf $file ; done ;}
